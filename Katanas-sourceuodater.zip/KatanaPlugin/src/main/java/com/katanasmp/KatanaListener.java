package com.katanasmp;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.*;

/** Keybinds (F / Shift+RightClick / Q), damage hooks, kill credit, rain entities, shadow hide. */
public class KatanaListener implements Listener {
    private final KatanaPlugin plugin;

    public KatanaListener(KatanaPlugin plugin) { this.plugin = plugin; }

    private Katana held(Player p) { return plugin.katanas().identify(p.getInventory().getItemInMainHand()); }

    // ================================================================= keybinds

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        Katana k = held(p);
        if (k == null) return;
        Slot s = p.isSneaking() ? plugin.slotFor("SNEAK_SWAP_HANDS") : null;
        if (s == null) s = plugin.slotFor("SWAP_HANDS");
        if (s == null) return;
        e.setCancelled(true);
        plugin.abilities().cast(p, k, s);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        Katana k = plugin.katanas().identify(e.getItemDrop().getItemStack());
        if (k == null) return;
        if (p.isSneaking() && plugin.getConfig().getBoolean("allow-drop-when-sneaking", true)) return;
        Slot s = plugin.slotFor("DROP_ITEM");
        if (s == null) return;
        e.setCancelled(true);
        plugin.abilities().cast(p, k, s);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        Katana k = plugin.katanas().identify(e.getItem());
        if (k == null) return;
        Slot s = plugin.slotFor(p.isSneaking() ? "SNEAK_RIGHT_CLICK" : "RIGHT_CLICK");
        if (s == null) return;
        plugin.abilities().cast(p, k, s);
    }

    // ============================================================ shadow hide

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!p.isSneaking()) return;
        Katana k = held(p);
        if (k == null || !k.has("SHADOW_HIDE", plugin.data().level(p.getUniqueId(), k.id))) return;
        e.setCancelled(true);
        plugin.shadow().hide(p, e.getRightClicked());
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        Player p = e.getPlayer();
        if (e.isSneaking() && plugin.shadow().isHiding(p)
                && System.currentTimeMillis() - plugin.shadow().hidingSince(p) > 1000) {
            plugin.shadow().exit(p, plugin.msg("shadow-exit"));
        }
    }

    // ================================================================== damage

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity d = e.getDamager();

        // entities spawned by domain rains: vanilla damage is replaced by our own (see onProjectileHit)
        if (d.hasMetadata("katana_owner")) {
            Player owner = plugin.abilities().ownerOf(d);
            if (!(d instanceof TNTPrimed) || owner == null || !plugin.abilities().valid(owner, e.getEntity())) {
                e.setCancelled(true);
            }
            return;
        }

        if (e.getEntity() instanceof Player) plugin.abilities().onVictimHit((Player) e.getEntity(), e);

        if (!(d instanceof Player)) return;
        final Player p = (Player) d;
        if (plugin.shadow().isHiding(p)) plugin.shadow().exit(p, plugin.msg("shadow-exit"));
        if (plugin.abilities().suppressHit) return;
        Katana k = held(p);
        if (k == null || !(e.getEntity() instanceof LivingEntity)) return;

        int level = plugin.data().level(p.getUniqueId(), k.id);
        World w = p.getWorld();
        double mult = k.stat("damage-multiplier", level, 1.0);
        if (Util.isNight(w)) mult *= k.stat("night-damage", level, 1.0);
        if (w.hasStorm()) mult *= k.stat("storm-damage", level, 1.0);
        if (p.isSneaking()) mult *= k.stat("sneak-damage", level, 1.0);
        e.setDamage(e.getDamage() * mult);

        double ls = k.stat("lifesteal", level, 0);
        if (ls > 0) plugin.abilities().heal(p, e.getDamage() * ls);

        // on-hit effects (highest tier of each effect wins); applied next tick to avoid nested damage
        Map<String, String> eff = new LinkedHashMap<String, String>();
        for (Map.Entry<Integer, List<String>> en : k.onHit.entrySet()) {
            if (en.getKey() > level) break;
            for (String s : en.getValue()) {
                String[] parts = s.split(":");
                String key = parts[0].toUpperCase(Locale.ROOT);
                if (key.equals("SELF") && parts.length > 1) key = "SELF_" + parts[1].toUpperCase(Locale.ROOT);
                eff.put(key, s);
            }
        }
        final LivingEntity victim = (LivingEntity) e.getEntity();
        final List<String> specs = new ArrayList<String>(eff.values());
        final Katana kk = k;
        Util.particle(victim.getLocation().add(0, 1, 0), k.hitParticle, 8, 0.3, 0.5, 0.3, 0.02, k.color);
        if (!specs.isEmpty()) {
            Bukkit.getScheduler().runTask(plugin, new Runnable() {
                public void run() {
                    if (victim.isDead()) return;
                    plugin.abilities().applyEffects(victim, p, specs);
                }
            });
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        Player p = (Player) e.getEntity();
        Katana k = held(p);
        if (k == null) return;
        int level = plugin.data().level(p.getUniqueId(), k.id);
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.FALL && k.has("FALL_IMMUNE", level)) {
            e.setCancelled(true);
            Util.particle(p.getLocation().add(0, 0.2, 0), k.auraParticle, 12, 0.4, 0.1, 0.4, 0.02, k.color);
            return;
        }
        if ((c == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION || c == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION)
                && k.has("EXPLOSION_RESIST", level)) {
            double resist = Math.min(0.95, k.stat("explosion-resist", level, 0.5));
            e.setDamage(e.getDamage() * (1.0 - resist));
        }
    }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) {
        if (plugin.abilities().isAnchored(e.getPlayer())) e.setCancelled(true);
    }

    // ============================================================ rain entities

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        Projectile pr = e.getEntity();
        if (!pr.hasMetadata("katana_owner")) return;
        plugin.abilities().onRainHit(pr, e.getHitEntity());
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        if (e.getEntity().hasMetadata("katana_owner")) e.blockList().clear();
    }

    // ================================================================ kill credit

    @EventHandler
    public void onKill(EntityDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (v instanceof Player) return;
        Player p = v.getKiller();
        if (p == null) return;
        Katana k = held(p);
        if (k == null) return;
        ProgressionManager.KillInfo i = new ProgressionManager.KillInfo();
        i.type = v.getType().name();
        i.hostile = Util.hostile(v);
        i.env = v.getWorld().getEnvironment().name();
        i.boss = Util.isBoss(v);
        CustomMobRegistry.Entry cm = plugin.mobs().match(v);
        if (cm != null) {
            i.customId = cm.id;
            i.credit = cm.credit;
            i.boss = i.boss || cm.boss;
            i.hostile = true;
        }
        plugin.progression().creditKill(p, k, i);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        plugin.progression().onDeath(p);
        plugin.shadow().exit(p, null);
        plugin.abilities().clearPlayer(p);
        plugin.tick().release(p);
    }

    // ================================================================ join / quit

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { plugin.pack().sendOnJoin(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.shadow().exit(p, null);
        plugin.abilities().clearPlayer(p);
        plugin.tick().release(p);
        plugin.data().save();
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        final Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, new Runnable() {
            public void run() {
                Katana k = held(p);
                if (k != null) plugin.katanas().refresh(p, k, plugin.data().level(p.getUniqueId(), k.id));
            }
        });
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent e) {
        PlayerResourcePackStatusEvent.Status s = e.getStatus();
        if (s == PlayerResourcePackStatusEvent.Status.DECLINED || s == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD) {
            e.getPlayer().sendMessage(plugin.msg("pack-declined"));
        }
    }

    @EventHandler
    public void onPluginDisable(PluginDisableEvent e) {
        plugin.mobs().unregisterAll(e.getPlugin());
    }
}
