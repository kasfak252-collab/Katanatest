package com.katanasmp;

/** The three skill slots every katana has. */
public enum Slot { ACTIVE, DEFENSE, ULTIMATE }
