package com.katanasmp.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/** Fired when a katana is about to level up. */
public class KatanaLevelUpEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String katanaId;
    private final int oldLevel;
    private final int newLevel;
    private boolean cancelled;

    public KatanaLevelUpEvent(Player player, String katanaId, int oldLevel, int newLevel) {
        this.player = player; this.katanaId = katanaId; this.oldLevel = oldLevel; this.newLevel = newLevel;
    }

    public Player getPlayer() { return player; }
    public String getKatanaId() { return katanaId; }
    public int getOldLevel() { return oldLevel; }
    public int getNewLevel() { return newLevel; }
    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { cancelled = c; }
    public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
