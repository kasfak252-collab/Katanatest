package com.katanasmp.api;

import com.katanasmp.CustomMobRegistry;
import com.katanasmp.Katana;
import com.katanasmp.KatanaPlugin;
import com.katanasmp.ProgressionManager;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.function.Predicate;

/**
 * Public API for other plugins.
 *
 * <pre>
 * KatanaAPI api = KatanaAPI.get();
 * if (api != null) {
 *     api.registerCustomMob(this, "demon_lord", e -> "Demon Lord".equals(e.getCustomName()), 5, false);
 * }
 * </pre>
 * Add <code>softdepend: [Katanas]</code> to your plugin.yml and compile against this jar (provided scope).
 */
public class KatanaAPI {
    private final KatanaPlugin plugin;

    public KatanaAPI(KatanaPlugin plugin) { this.plugin = plugin; }

    /** Returns the API or null when Katanas is not installed. */
    public static KatanaAPI get() {
        RegisteredServiceProvider<KatanaAPI> rsp = Bukkit.getServicesManager().getRegistration(KatanaAPI.class);
        return rsp == null ? null : rsp.getProvider();
    }

    /**
     * Attach your custom mob. When a player holding a katana kills an entity that matches,
     * it counts as {@code credit} kills for every KILL task (and as a boss kill if boss is true).
     */
    public void registerCustomMob(Plugin owner, String id, Predicate<Entity> matcher, int credit, boolean boss) {
        plugin.mobs().register(new CustomMobRegistry.Entry(id, matcher, credit, boss, owner));
    }

    public void unregisterCustomMobs(Plugin owner) { plugin.mobs().unregisterAll(owner); }

    /** Manually credit a kill (for mobs you cannot match with a predicate). Uses the katana in the player's main hand. */
    public boolean creditKill(Player p, String customMobId, int credit, boolean boss) {
        Katana k = plugin.katanas().identify(p.getInventory().getItemInMainHand());
        if (k == null) return false;
        ProgressionManager.KillInfo info = new ProgressionManager.KillInfo();
        info.type = "CUSTOM";
        info.customId = customMobId;
        info.credit = Math.max(1, credit);
        info.boss = boss;
        info.hostile = true;
        info.env = p.getWorld().getEnvironment().name();
        plugin.progression().creditKill(p, k, info);
        return true;
    }

    /** Registers an additional katana from a config section (same format as katanas.yml). */
    public Katana registerKatana(Plugin owner, String id, ConfigurationSection section) {
        Katana k = Katana.load(id.toLowerCase(), section);
        k.source = owner.getName();
        plugin.katanas().register(k);
        return k;
    }

    public String getKatanaId(ItemStack item) {
        Katana k = plugin.katanas().identify(item);
        return k == null ? null : k.id;
    }

    public ItemStack createKatana(String id, int level) {
        Katana k = plugin.katanas().get(id);
        return k == null ? null : plugin.katanas().create(k, level);
    }

    public int getLevel(Player p, String katanaId) { return plugin.data().level(p.getUniqueId(), katanaId.toLowerCase()); }

    public void setLevel(Player p, String katanaId, int level) {
        plugin.data().setLevel(p.getUniqueId(), katanaId.toLowerCase(), level);
        plugin.data().setProgress(p.getUniqueId(), katanaId.toLowerCase(), 0);
    }

    /** True if the katana in the player's hand has the flag unlocked at its current level. */
    public boolean hasFlag(Player p, String flag) {
        Katana k = plugin.katanas().identify(p.getInventory().getItemInMainHand());
        return k != null && k.has(flag.toUpperCase(), plugin.data().level(p.getUniqueId(), k.id));
    }

    /** Time-stop plugins should call this and skip the player if it returns true. */
    public boolean isImmuneToTimeStop(Player p) {
        return hasFlag(p, "TIMESTOP_IMMUNE") || plugin.shadow().isHiding(p);
    }

    public boolean isHidingInShadow(Player p) { return plugin.shadow().isHiding(p); }
}
