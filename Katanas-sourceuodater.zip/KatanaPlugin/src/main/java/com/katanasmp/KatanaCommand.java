package com.katanasmp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** /katana give|setlevel|list|info|aura|pack|reload  and the aura aliases /crimson /celestial /shadow /gravity */
public class KatanaCommand implements CommandExecutor, TabCompleter {
    private static final Map<String, String> ALIAS = new LinkedHashMap<String, String>();
    static {
        ALIAS.put("crimson", "crimson_moon");
        ALIAS.put("celestial", "celestial_blade");
        ALIAS.put("shadow", "shadow_realm");
        ALIAS.put("gravity", "gravity_edge");
    }
    private static final String[] AURA_FLAGS = {"MOB_FEAR", "MOB_WIPE", "PRESSURE", "PROJECTILE_BARRIER", "AURA_BURN"};

    private final KatanaPlugin plugin;

    public KatanaCommand(KatanaPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String name = c.getName().toLowerCase(Locale.ROOT);
        if (ALIAS.containsKey(name)) return aura(s, ALIAS.get(name));
        if (a.length == 0) return help(s);
        String sub = a[0].toLowerCase(Locale.ROOT);

        if (ALIAS.containsKey(sub)) return aura(s, ALIAS.get(sub));

        switch (sub) {
            case "list": return list(s);
            case "info": return info(s);
            case "aura": return aura(s, null);
            case "pack": return pack(s);
            case "give": return give(s, a);
            case "setlevel": return setLevel(s, a);
            case "reload":
                if (!s.hasPermission("katana.admin")) return deny(s);
                plugin.loadAll();
                s.sendMessage(Util.color("&aKatanas reloaded (" + plugin.katanas().all().size() + " katanas)."));
                return true;
            default: return help(s);
        }
    }

    private boolean deny(CommandSender s) { s.sendMessage(plugin.msg("no-permission")); return true; }

    private boolean help(CommandSender s) {
        s.sendMessage(Util.color("&6&lKatanas &7- /katana <list|info|aura|pack>"));
        if (s.hasPermission("katana.admin")) s.sendMessage(Util.color("&7Admin: /katana give <player> <id> [level] | setlevel <player> <id> <level> | reload"));
        return true;
    }

    private boolean list(CommandSender s) {
        s.sendMessage(Util.color("&6&lKatanas:"));
        for (Katana k : plugin.katanas().all()) {
            s.sendMessage(Util.color("&8- &f" + k.id + " &7(" + k.name + "&7, " + k.element + ")"));
        }
        return true;
    }

    private boolean info(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        Katana k = plugin.katanas().identify(p.getInventory().getItemInMainHand());
        if (k == null) { s.sendMessage(Util.color("&cHold a katana first.")); return true; }
        int level = plugin.data().level(p.getUniqueId(), k.id);
        s.sendMessage(Util.color(k.name + " &7- level &e" + level + "&7/" + plugin.maxLevel()));
        if (level < plugin.maxLevel()) {
            ProgressionManager.Task t = plugin.progression().taskFor(k, level);
            int prog = plugin.data().progress(p.getUniqueId(), k.id);
            s.sendMessage(Util.color("&7Task: &f" + plugin.progression().describe(k, level)
                    + (t != null ? " &8(" + prog + "/" + t.amount + ")" : "")));
        } else {
            s.sendMessage(Util.color("&6Maximum level reached."));
        }
        return true;
    }

    private int auraUnlock(Katana k) {
        int best = 0;
        for (String f : AURA_FLAGS) {
            Integer u = k.flags.get(f);
            if (u != null && (best == 0 || u < best)) best = u;
        }
        return best;
    }

    private boolean aura(CommandSender s, String katanaId) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        Katana k;
        if (katanaId == null) k = plugin.katanas().identify(p.getInventory().getItemInMainHand());
        else k = plugin.katanas().get(katanaId);
        if (k == null) { s.sendMessage(Util.color("&cHold a katana (or use /crimson, /celestial, /shadow, /gravity).")); return true; }
        int need = auraUnlock(k);
        int level = plugin.data().level(p.getUniqueId(), k.id);
        if (need == 0 || level < need) {
            s.sendMessage(plugin.msg("aura-locked").replace("{level}", String.valueOf(need == 0 ? plugin.maxLevel() : need)));
            return true;
        }
        boolean now = !plugin.data().aura(p.getUniqueId(), k.id);
        plugin.data().setAura(p.getUniqueId(), k.id, now);
        s.sendMessage(plugin.msg(now ? "aura-on" : "aura-off"));
        return true;
    }

    private boolean pack(CommandSender s) {
        if (!(s instanceof Player)) return true;
        if (plugin.pack().send((Player) s)) s.sendMessage(plugin.msg("pack-sent"));
        else s.sendMessage(Util.color("&cResource pack is not configured (config.yml > resource-pack)."));
        return true;
    }

    private boolean give(CommandSender s, String[] a) {
        if (!s.hasPermission("katana.admin")) return deny(s);
        if (a.length < 3) { s.sendMessage(Util.color("&cUsage: /katana give <player> <id> [level]")); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        Katana k = plugin.katanas().get(a[2]);
        if (t == null || k == null) { s.sendMessage(Util.color("&cUnknown player or katana id.")); return true; }
        int level = plugin.data().level(t.getUniqueId(), k.id);
        if (a.length > 3) {
            try { level = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { s.sendMessage(Util.color("&cLevel must be a number.")); return true; }
            plugin.data().setLevel(t.getUniqueId(), k.id, level);
            plugin.data().setProgress(t.getUniqueId(), k.id, 0);
            level = plugin.data().level(t.getUniqueId(), k.id);
        }
        ItemStack it = plugin.katanas().create(k, level);
        Map<Integer, ItemStack> left = t.getInventory().addItem(it);
        for (ItemStack rest : left.values()) t.getWorld().dropItemNaturally(t.getLocation(), rest);
        s.sendMessage(Util.color("&aGave " + k.name + " &ato " + t.getName() + " &7(level " + level + ")"));
        return true;
    }

    private boolean setLevel(CommandSender s, String[] a) {
        if (!s.hasPermission("katana.admin")) return deny(s);
        if (a.length < 4) { s.sendMessage(Util.color("&cUsage: /katana setlevel <player> <id> <level>")); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        Katana k = plugin.katanas().get(a[2]);
        if (t == null || k == null) { s.sendMessage(Util.color("&cUnknown player or katana id.")); return true; }
        try {
            plugin.data().setLevel(t.getUniqueId(), k.id, Integer.parseInt(a[3]));
            plugin.data().setProgress(t.getUniqueId(), k.id, 0);
        } catch (NumberFormatException ex) { s.sendMessage(Util.color("&cLevel must be a number.")); return true; }
        s.sendMessage(Util.color("&aLevel set."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<String>();
        if (!c.getName().equalsIgnoreCase("katana")) return out;
        if (a.length == 1) {
            out.addAll(Arrays.asList("list", "info", "aura", "pack"));
            out.addAll(ALIAS.keySet());
            if (s.hasPermission("katana.admin")) out.addAll(Arrays.asList("give", "setlevel", "reload"));
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("give") || a[0].equalsIgnoreCase("setlevel"))) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (a.length == 3 && (a[0].equalsIgnoreCase("give") || a[0].equalsIgnoreCase("setlevel"))) {
            out.addAll(plugin.katanas().ids());
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        List<String> filtered = new ArrayList<String>();
        for (String o : out) if (o.toLowerCase(Locale.ROOT).startsWith(last)) filtered.add(o);
        return filtered;
    }
}
