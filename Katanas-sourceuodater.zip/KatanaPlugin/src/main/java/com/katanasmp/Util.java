package com.katanasmp;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Flying;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.entity.Slime;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.lang.reflect.Field;
import java.util.*;

/** Version-safe helpers (particles, potions, sounds, conditions). */
public final class Util {
    private Util() { }

    public static final Set<String> BOSSES = new HashSet<String>(
            Arrays.asList("ENDER_DRAGON", "WITHER", "WARDEN", "ELDER_GUARDIAN"));

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static String strip(String s) { return ChatColor.stripColor(color(s)); }

    // ------------------------------------------------------------------ config

    /** Reads either a single section or a list of maps under key. */
    public static List<ConfigurationSection> sections(ConfigurationSection c, String key) {
        List<ConfigurationSection> out = new ArrayList<ConfigurationSection>();
        if (c == null) return out;
        if (c.isConfigurationSection(key)) {
            out.add(c.getConfigurationSection(key));
        } else {
            for (Map<?, ?> m : c.getMapList(key)) {
                out.add(new MemoryConfiguration().createSection("x", m));
            }
        }
        return out;
    }

    // --------------------------------------------------------------- particles

    private static final Map<String, String[]> PALT = new HashMap<String, String[]>();
    static {
        alt("REDSTONE", "DUST");
        alt("DUST", "REDSTONE");
        alt("SMOKE_NORMAL", "SMOKE");
        alt("SMOKE", "SMOKE_NORMAL");
        alt("SMOKE_LARGE", "LARGE_SMOKE");
        alt("LARGE_SMOKE", "SMOKE_LARGE");
        alt("VILLAGER_HAPPY", "HAPPY_VILLAGER");
        alt("HAPPY_VILLAGER", "VILLAGER_HAPPY");
        alt("SPELL_WITCH", "WITCH");
        alt("WITCH", "SPELL_WITCH");
        alt("DRIP_LAVA", "DRIPPING_LAVA", "FLAME");
        alt("DRIP_WATER", "DRIPPING_WATER");
        alt("CRIT_MAGIC", "ENCHANTED_HIT");
        alt("EXPLOSION_LARGE", "EXPLOSION");
        alt("EXPLOSION", "EXPLOSION_LARGE");
        alt("EXPLOSION_NORMAL", "POOF");
        alt("POOF", "EXPLOSION_NORMAL");
        alt("WATER_SPLASH", "SPLASH");
        alt("SPLASH", "WATER_SPLASH");
        alt("WATER_BUBBLE", "BUBBLE");
        alt("BUBBLE", "WATER_BUBBLE");
        alt("ELECTRIC_SPARK", "CRIT_MAGIC", "ENCHANTED_HIT", "CRIT");
        alt("SNOWFLAKE", "ITEM_SNOWBALL", "SNOWBALL", "CLOUD");
        alt("SOUL", "SMOKE_NORMAL", "SMOKE");
        alt("FIREWORKS_SPARK", "FIREWORK");
    }

    private static void alt(String name, String... alts) { PALT.put(name, alts); }

    /** A resolved particle plus the real field name that was found. */
    public static final class PRef {
        public final Particle particle;
        public final String key;
        PRef(Particle p, String k) { particle = p; key = k; }
    }

    private static final Map<String, PRef> PCACHE = new HashMap<String, PRef>();

    public static PRef pref(String name) {
        String n = name == null ? "FLAME" : name.toUpperCase(Locale.ROOT);
        PRef cached = PCACHE.get(n);
        if (cached != null) return cached;
        List<String> tries = new ArrayList<String>();
        tries.add(n);
        String[] alts = PALT.get(n);
        if (alts != null) tries.addAll(Arrays.asList(alts));
        tries.add("FLAME");
        PRef found = null;
        for (String t : tries) {
            try {
                Field f = Particle.class.getField(t);
                Object o = f.get(null);
                if (o instanceof Particle) { found = new PRef((Particle) o, t); break; }
            } catch (Throwable ignored) { }
        }
        PCACHE.put(n, found);
        return found;
    }

    public static Color parseColor(String hex) {
        try {
            String h = hex.startsWith("#") ? hex.substring(1) : hex;
            int rgb = Integer.parseInt(h, 16);
            return Color.fromRGB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        } catch (Exception e) {
            return Color.WHITE;
        }
    }

    public static void particle(Location loc, String name, int count, double ox, double oy, double oz, double speed, String hex) {
        spawn(null, loc, name, count, ox, oy, oz, speed, hex);
    }

    /** Particle visible only to one player (used by the vibration radar). */
    public static void playerParticle(Player viewer, Location loc, String name, int count, double ox, double oy, double oz, double speed, String hex) {
        spawn(viewer, loc, name, count, ox, oy, oz, speed, hex);
    }

    private static void spawn(Player viewer, Location loc, String name, int count, double ox, double oy, double oz, double speed, String hex) {
        try {
            PRef r = pref(name);
            World w = loc.getWorld();
            if (r == null || w == null) return;
            boolean dust = r.key.equals("REDSTONE") || r.key.equals("DUST");
            if (dust) {
                Particle.DustOptions opt = new Particle.DustOptions(parseColor(hex == null ? "#FFFFFF" : hex), 1.3f);
                if (viewer != null) viewer.spawnParticle(r.particle, loc, count, ox, oy, oz, 0, opt);
                else w.spawnParticle(r.particle, loc, count, ox, oy, oz, 0, opt);
            } else {
                if (viewer != null) viewer.spawnParticle(r.particle, loc, count, ox, oy, oz, speed);
                else w.spawnParticle(r.particle, loc, count, ox, oy, oz, speed);
            }
        } catch (Throwable ignored) { }
    }

    public static void ring(Location c, double r, int points, String particle, String hex, double rot) {
        for (int i = 0; i < points; i++) {
            double a = rot + 2 * Math.PI * i / points;
            particle(c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r), particle, 1, 0, 0, 0, 0, hex);
        }
    }

    public static void line(Location a, Location b, String particle, String hex) {
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len < 0.1) return;
        v.normalize().multiply(0.5);
        Location cur = a.clone();
        for (double d = 0; d < len; d += 0.5) {
            particle(cur, particle, 1, 0, 0, 0, 0, hex);
            cur.add(v);
        }
    }

    // ------------------------------------------------------------------ sounds

    private static final Map<String, Sound> SCACHE = new HashMap<String, Sound>();

    /** name may list alternatives separated by '|' (names differ between versions). */
    public static void sound(Location l, String name, float vol, float pitch) {
        try {
            Sound s = SCACHE.get(name);
            if (s == null) {
                for (String alt : name.split("\\|")) {
                    try {
                        Object o = Sound.class.getField(alt.trim()).get(null);
                        if (o instanceof Sound) { s = (Sound) o; break; }
                    } catch (Throwable ignored) { }
                }
                if (s != null) SCACHE.put(name, s);
            }
            if (s != null && l.getWorld() != null) l.getWorld().playSound(l, s, vol, pitch);
        } catch (Throwable ignored) { }
    }

    // ----------------------------------------------------------------- potions

    private static final Map<String, String[]> TALT = new HashMap<String, String[]>();
    static {
        TALT.put("SLOW", new String[]{"SLOWNESS"});
        TALT.put("SLOWNESS", new String[]{"SLOW"});
        TALT.put("INCREASE_DAMAGE", new String[]{"STRENGTH"});
        TALT.put("STRENGTH", new String[]{"INCREASE_DAMAGE"});
        TALT.put("DAMAGE_RESISTANCE", new String[]{"RESISTANCE"});
        TALT.put("RESISTANCE", new String[]{"DAMAGE_RESISTANCE"});
        TALT.put("JUMP", new String[]{"JUMP_BOOST"});
        TALT.put("JUMP_BOOST", new String[]{"JUMP"});
        TALT.put("FAST_DIGGING", new String[]{"HASTE"});
        TALT.put("HASTE", new String[]{"FAST_DIGGING"});
        TALT.put("SLOW_DIGGING", new String[]{"MINING_FATIGUE"});
        TALT.put("MINING_FATIGUE", new String[]{"SLOW_DIGGING"});
        TALT.put("CONFUSION", new String[]{"NAUSEA"});
        TALT.put("NAUSEA", new String[]{"CONFUSION"});
        TALT.put("HARM", new String[]{"INSTANT_DAMAGE"});
        TALT.put("HEAL", new String[]{"INSTANT_HEALTH"});
    }

    public static PotionEffectType potionType(String name) {
        String n = name.trim().toUpperCase(Locale.ROOT);
        PotionEffectType t = PotionEffectType.getByName(n);
        if (t != null) return t;
        String[] alts = TALT.get(n);
        if (alts != null) for (String a : alts) { t = PotionEffectType.getByName(a); if (t != null) return t; }
        return null;
    }

    /**
     * "NAME:amp" (2 parts) uses defTicks; "NAME:ticks:amp" (3 parts) is explicit.
     * Returns null for unknown effects.
     */
    public static PotionEffect effect(String spec, int defTicks, boolean ambient, boolean particles) {
        String[] p = spec.split(":");
        PotionEffectType t = potionType(p[0]);
        if (t == null) return null;
        int ticks = defTicks, amp = 0;
        try {
            if (p.length == 2) amp = Integer.parseInt(p[1].trim());
            else if (p.length >= 3) { ticks = Integer.parseInt(p[1].trim()); amp = Integer.parseInt(p[2].trim()); }
        } catch (NumberFormatException ignored) { }
        return new PotionEffect(t, ticks, amp, ambient, particles);
    }

    // ------------------------------------------------------------- world state

    public static boolean isNight(World w) {
        if (w.getEnvironment() != World.Environment.NORMAL) return false;
        long t = w.getTime();
        return t >= 13000 && t < 23000;
    }

    public static boolean openSky(Location l) {
        World w = l.getWorld();
        return w != null && w.getEnvironment() == World.Environment.NORMAL && l.getBlockY() >= w.getHighestBlockYAt(l);
    }

    public static boolean cond(Player p, String c) {
        Location l = p.getLocation();
        switch (c.trim().toLowerCase(Locale.ROOT)) {
            case "night": return isNight(p.getWorld());
            case "day": return !isNight(p.getWorld());
            case "dark": {
                Block b = l.getBlock();
                if (b.getLightFromSky() >= 12) return isNight(p.getWorld());
                return b.getLightFromBlocks() <= 6;
            }
            case "sneak": return p.isSneaking();
            case "sky": return openSky(l);
            case "storm": return p.getWorld().hasStorm();
            case "water": return l.getBlock().isLiquid();
            case "lowhp": return p.getHealth() <= p.getMaxHealth() * 0.4;
            default: return true;
        }
    }

    public static boolean hostile(Entity e) {
        return e instanceof Monster || e instanceof Slime || e instanceof Flying || e instanceof Shulker;
    }

    public static boolean isBoss(Entity e) { return BOSSES.contains(e.getType().name()); }

    public static EntityType entityType(String... names) {
        for (String n : names) {
            try { return EntityType.valueOf(n); } catch (Exception ignored) { }
        }
        return null;
    }
}
