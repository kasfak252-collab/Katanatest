package com.katanasmp;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/**
 * Lets any other plugin attach its custom mobs to the katana progression.
 * Three ways in: the Java API, the custom-mobs section of config.yml, or plain
 * scoreboard tags (katana_mob / katana_credit_N / katana_boss).
 */
public class CustomMobRegistry {
    public static class Entry {
        public final String id;
        public final Predicate<Entity> matcher;
        public final int credit;
        public final boolean boss;
        public final Plugin owner;

        public Entry(String id, Predicate<Entity> matcher, int credit, boolean boss, Plugin owner) {
            this.id = id; this.matcher = matcher; this.credit = Math.max(1, credit); this.boss = boss; this.owner = owner;
        }
    }

    private final KatanaPlugin plugin;
    private final List<Entry> entries = new CopyOnWriteArrayList<Entry>();

    public CustomMobRegistry(KatanaPlugin plugin) { this.plugin = plugin; }

    public void register(Entry e) { entries.add(e); }

    public void unregisterAll(Plugin owner) {
        for (Entry e : entries) if (e.owner == owner) entries.remove(e);
    }

    /** Re-reads the custom-mobs section of config.yml. */
    public void loadConfig() {
        unregisterAll(plugin);
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("custom-mobs");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            final ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null || !c.getBoolean("enabled", true)) continue;
            final String name = Util.strip(c.getString("name", ""));
            final String tag = c.getString("tag", "");
            final String meta = c.getString("metadata", "");
            final String type = c.getString("type", "").toUpperCase();
            if (name.isEmpty() && tag.isEmpty() && meta.isEmpty() && type.isEmpty()) continue;
            Predicate<Entity> p = new Predicate<Entity>() {
                public boolean test(Entity e) {
                    if (!type.isEmpty() && !e.getType().name().equals(type)) return false;
                    if (!name.isEmpty()) {
                        String n = e.getCustomName();
                        if (n == null || !ChatColor.stripColor(n).equalsIgnoreCase(name)) return false;
                    }
                    if (!tag.isEmpty() && !e.getScoreboardTags().contains(tag)) return false;
                    if (!meta.isEmpty() && !e.hasMetadata(meta)) return false;
                    return true;
                }
            };
            entries.add(new Entry(id, p, c.getInt("credit", 1), c.getBoolean("boss", false), plugin));
        }
    }

    /** Returns the matching entry or null if this is not a registered custom mob. */
    public Entry match(Entity e) {
        for (Entry en : entries) {
            try { if (en.matcher.test(e)) return en; } catch (Throwable ignored) { }
        }
        Set<String> tags = e.getScoreboardTags();
        if (tags.contains("katana_mob") || tags.contains("katana_boss")) {
            int credit = 1;
            for (String t : tags) {
                if (t.startsWith("katana_credit_")) {
                    try { credit = Integer.parseInt(t.substring("katana_credit_".length())); } catch (NumberFormatException ignored) { }
                }
            }
            return new Entry("tag:" + e.getType().name().toLowerCase(), null, credit, tags.contains("katana_boss"), null);
        }
        return null;
    }

    public boolean isCustom(Entity e) { return match(e) != null; }
}
