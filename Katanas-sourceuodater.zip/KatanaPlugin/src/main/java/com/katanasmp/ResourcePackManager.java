package com.katanasmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** Sends the optional katana resource pack. */
public class ResourcePackManager {
    private final KatanaPlugin plugin;

    public ResourcePackManager(KatanaPlugin plugin) { this.plugin = plugin; }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("resource-pack.enabled", false)
                && !plugin.getConfig().getString("resource-pack.url", "").trim().isEmpty();
    }

    public void sendOnJoin(final Player p) {
        if (!enabled() || !plugin.getConfig().getBoolean("resource-pack.send-on-join", true)) return;
        long delay = plugin.getConfig().getLong("resource-pack.send-delay-ticks", 40L);
        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            public void run() { if (p.isOnline()) send(p); }
        }, delay);
    }

    public boolean send(Player p) {
        if (!enabled()) return false;
        String url = plugin.getConfig().getString("resource-pack.url", "").trim();
        String sha = plugin.getConfig().getString("resource-pack.sha1", "").trim();
        try {
            if (sha.length() == 40) p.setResourcePack(url, hex(sha));
            else p.setResourcePack(url);
            return true;
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not send resource pack: " + t.getMessage());
            return false;
        }
    }

    private static byte[] hex(String s) {
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }
}
