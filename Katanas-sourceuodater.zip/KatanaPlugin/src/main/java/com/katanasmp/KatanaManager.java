package com.katanasmp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.*;

/** Registry of katanas + item creation / identification. */
public class KatanaManager {
    public static final String TAG = "katana:";
    private final KatanaPlugin plugin;
    private final Map<String, Katana> katanas = new LinkedHashMap<String, Katana>();

    public KatanaManager(KatanaPlugin plugin) { this.plugin = plugin; }

    public void load() {
        katanas.clear();
        File f = new File(plugin.getDataFolder(), "katanas.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection root = y.getConfigurationSection("katanas");
        if (root == null) { plugin.getLogger().warning("katanas.yml has no 'katanas' section."); return; }
        for (String id : root.getKeys(false)) {
            try {
                katanas.put(id.toLowerCase(), Katana.load(id.toLowerCase(), root.getConfigurationSection(id)));
            } catch (Exception ex) {
                plugin.getLogger().warning("Could not load katana '" + id + "': " + ex.getMessage());
            }
        }
    }

    public void register(Katana k) { katanas.put(k.id, k); }
    public Katana get(String id) { return id == null ? null : katanas.get(id.toLowerCase()); }
    public Collection<Katana> all() { return katanas.values(); }
    public Set<String> ids() { return katanas.keySet(); }

    /** Finds which katana an item is (reads the hidden-looking "katana:id" lore line). */
    public Katana identify(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        ItemMeta m = it.getItemMeta();
        if (m == null || !m.hasLore()) return null;
        List<String> lore = m.getLore();
        for (int i = lore.size() - 1; i >= 0; i--) {
            String s = ChatColor.stripColor(lore.get(i));
            if (s != null && s.startsWith(TAG)) return katanas.get(s.substring(TAG.length()).trim().toLowerCase());
        }
        return null;
    }

    public ItemStack create(Katana k, int level) {
        Material m = Material.matchMaterial(k.baseMaterial);
        if (m == null) m = Material.DIAMOND_SWORD;
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(k.name));
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        setCmd(meta, k.cmd);
        meta.setLore(buildLore(k, level));
        it.setItemMeta(meta);
        return it;
    }

    private void setCmd(ItemMeta m, int cmd) {
        if (cmd <= 0 || !plugin.getConfig().getBoolean("resource-pack.custom-model-data", true)) return;
        try {
            ItemMeta.class.getMethod("setCustomModelData", Integer.class).invoke(m, Integer.valueOf(cmd));
        } catch (Throwable ignored) { /* 1.13: no CustomModelData */ }
    }

    public List<String> buildLore(Katana k, int level) {
        List<String> l = new ArrayList<String>();
        l.add(Util.color("&8&m------------------------"));
        l.add(Util.color("&7Element: &f" + k.element));
        l.add(Util.color("&7Level: &e" + level + "&7/" + plugin.maxLevel()));
        l.add("");
        for (Slot s : Slot.values()) {
            AbilityDef a = k.ability(s, level);
            String key = plugin.keyLabel(s);
            if (a != null) {
                l.add(Util.color("&6" + key + " &7- &f" + a.name + " &8(" + (int) a.d("cooldown", 20) + "s)"));
            } else {
                int u = k.firstUnlock(s);
                if (u > 0) l.add(Util.color("&6" + key + " &8- Locked (Lv." + u + ")"));
            }
        }
        l.add("");
        l.add(Util.color("&8" + TAG + k.id));
        return l;
    }

    /** Updates the lore of the held katana when its level changed (avoids re-equip flicker otherwise). */
    public void refresh(Player p, Katana k, int level) {
        ItemStack it = p.getInventory().getItemInMainHand();
        if (identify(it) != k) return;
        ItemMeta m = it.getItemMeta();
        if (m == null) return;
        List<String> old = m.getLore();
        if (old != null) {
            for (String line : old) {
                String s = ChatColor.stripColor(line);
                if (s != null && s.startsWith("Level: ")) {
                    try {
                        int shown = Integer.parseInt(s.substring(7, s.indexOf('/')).trim());
                        if (shown == level) return;
                    } catch (Exception ignored) { }
                }
            }
        }
        m.setLore(buildLore(k, level));
        it.setItemMeta(m);
        p.getInventory().setItemInMainHand(it);
    }
}
