package com.katanasmp;

import org.bukkit.configuration.ConfigurationSection;

import java.util.List;
import java.util.Locale;

/** One stage of an ability, read from katanas.yml. */
public class AbilityDef {
    public final Slot slot;
    public final ConfigurationSection c;
    public final int unlock;
    public final String name;
    public final String type;

    public AbilityDef(Slot slot, ConfigurationSection c) {
        this.slot = slot;
        this.c = c;
        this.unlock = c.getInt("unlock", 1);
        this.name = c.getString("name", slot.name());
        this.type = c.getString("type", "WAVE").toUpperCase(Locale.ROOT);
    }

    public double d(String k, double def) { return c.getDouble(k, def); }
    public int i(String k, int def) { return c.getInt(k, def); }
    public boolean b(String k, boolean def) { return c.getBoolean(k, def); }
    public String s(String k, String def) { return c.getString(k, def); }
    public List<String> list(String k) { return c.getStringList(k); }
    public List<ConfigurationSection> sections(String k) { return Util.sections(c, k); }
}
