# Katanas - 15 levelling katanas plugin

15 katanas, each with 12 levels, its own aura (particles), passives, 3 skills and an ultimate domain.
Includes a custom-mob API for other plugins and an optional resource pack.

## Build (needs JDK 8+ and Maven)
```
mvn clean package
```
The jar is created at `target/Katanas.jar`. Drop it into `plugins/`.
It is compiled against Spigot 1.13 API with `api-version: 1.13`, so one jar loads on **1.13 -> latest** (Spigot / Paper).
Particles, potions and sounds are looked up by name with fallbacks, so renamed constants (1.20.5+) still work.
If the Spigot repo is unavailable, use Paper's API (`com.destroystokyo.paper:paper-api:1.13.2-R0.1-SNAPSHOT`) in pom.xml.

> Not tested on a live server yet. Build it, start a test server and run `/katana give <you> blaze_edge 12`.

## Controls (changeable in config.yml > keybinds)
| Key | Slot |
|---|---|
| F (swap hands) | Active skill (unlocks level 4, upgrades level 8) |
| Shift + Right-Click | Defense barrier (unlocks level 5) |
| Q (drop) | Ultimate domain (unlocks level 9, full power at 12). Shift+Q still drops the katana |
| Sneak + Right-Click on an entity | Shadow Realm only: hide inside its shadow |

## Commands
`/katana list | info | aura | pack`  -  `/crimson aura`, `/celestial aura`, `/shadow aura`, `/gravity aura`
Admin (`katana.admin`): `/katana give <player> <id> [level]`, `/katana setlevel <player> <id> <level>`, `/katana reload`

## Levelling
Each level needs a hard task from `progression.yml` (kills, travel, skill uses, blocked projectiles, kill streak, boss kill).
Skill power scales with level (about 54% at level 1 up to 100% at 12). Everything is editable in `katanas.yml`.

## Custom mobs from other plugins (they give katana progress too)
1. **No code:** give the mob scoreboard tags `katana_mob`, `katana_credit_5`, `katana_boss`
   (e.g. `/summon zombie ~ ~ ~ {Tags:["katana_mob","katana_credit_5"]}`).
2. **Config:** add it under `custom-mobs:` in config.yml (match by name / tag / metadata key / entity type).
3. **Java API:**
```java
KatanaAPI api = KatanaAPI.get();               // null if Katanas is not installed
if (api != null) {
    api.registerCustomMob(this, "demon_lord",
        e -> "Demon Lord".equals(e.getCustomName()), 5, false);   // 5 kills of credit, not a boss
}
```
Add `softdepend: [Katanas]` to your plugin.yml. Events: `KatanaKillCreditEvent` (change or cancel the credit),
`KatanaAbilityCastEvent` (block skills in regions), `KatanaLevelUpEvent`.
Time-stop plugins can call `api.isImmuneToTimeStop(player)`. You can also add whole katanas with `api.registerKatana(...)`.

## Resource pack (optional)
Two packs are included (CustomModelData 1001-1015, matching `cmd:` in katanas.yml):
* **KatanasPack.zip** - 64x64 HD and **animated** (16 frames: shine sweeping along the blade, pulsing glow, plus a
  per-katana effect: embers, bubbles, leaves, stars, wisps, snow, blood drops, lightning, orbiting orbs, sound rings).
* **KatanasPack-Classic16.zip** - 16x16 pixel-art, static, vanilla style.

Works on 1.14 - 1.21.3 (model overrides) and 1.21.4+ (item definitions).
1. Upload the zip somewhere with a **direct** download link.
2. In config.yml set `resource-pack.enabled: true`, `url`, and `sha1`:
   * HD animated: `cb6b13d46ff1fbd8810ab5fae55cb476d63a3c4f`
   * Classic 16x: `dc8803e5cc96005fb8c081beab8659d16ec51771`
   (recompute the sha1 if you edit or re-zip a pack, or leave `sha1` empty).
3. Players get it on join, or with `/katana pack`. Set `custom-model-data: false` to keep vanilla sword models.

To use your own art: replace the PNGs in `resourcepack/assets/katanas/textures/item/` (same file names).
For animation keep the frames stacked vertically (square frames) next to a `<name>.png.mcmeta`.
Then run `python3 tools/make_pack.py` (needs `pip install pillow numpy`) to rebuild both zips.

## Known limits
* Needs 1.13 or newer (older versions lack the API this uses).
* Time and weather changes during domains are client-side per player (no sky-colour change beyond night/rain).
* Echo Pulse "silent steps" uses `setSilent`, which hides server-played sounds; the client's own footstep sound cannot be removed without ProtocolLib.
* Shadow Clone Dash is a dash with a smoke trail, not a real decoy entity.
* Domain TNT/trident rains are capped (`abilities.max-rain-entities`) to protect TPS and never break blocks.
